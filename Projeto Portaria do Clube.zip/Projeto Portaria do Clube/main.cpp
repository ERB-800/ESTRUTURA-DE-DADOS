#include <iostream> //esta biblioteca � usada para lidar com opera��es de entrada/sa�da padr�o em C++.  ex: cin, cout.
#include <fstream> // Esta biblioteca � usada para realizar opera��es de entrada/sa�da em arquivos.ifstream(para leitura de um arquivo), ofstream(para grava��o em um arquivo) e fstream(para opera��es bidirecionais de entrada/sa�da). 
#include <limits> //esta biblioteca fornece fun��es e constantes para trabalhar com limita��es de tipo de dados em C++.ex: digitar letrasno lugar de n�meros vai dar erro.

using namespace std;

struct RegistroEntradaPortaria {
    int numeroCarteirinha;
    string nome;
    bool entrada;
    RegistroEntradaPortaria* proximo;

    RegistroEntradaPortaria(int _numeroCarteirinha, const string& _nome, bool _entrada)
        : numeroCarteirinha(_numeroCarteirinha), nome(_nome), entrada(_entrada), proximo(NULL) {}

//utilizado para inicializar inst�ncias da classe RegistroEntradaPortaria com valores espec�ficos para os membros da classe. 
        
//int numeroCarteirinha: � uma vari�vel inteira que armazena o n�mero da carteirinha.
//string nome: � uma vari�vel do tipo string que armazena o nome associado � carteirinha.
//bool entrada: � uma vari�vel booleana que indica se a entrada foi permitida ou n�o (true para entrada permitida, false para entrada n�o permitida).
//RegistroEntradaPortaria* proximo: � um ponteiro para outra inst�ncia da mesma estrutura RegistroEntradaPortaria. 
//Esse ponteiro � utilizado para criar uma lista encadeada, conectando inst�ncias consecutivas da estrutura.
//RegistroEntradaPortaria(int _numeroCarteirinha, const string& _nome, bool _entrada): � o construtor da estrutura. 
//Ele recebe tr�s par�metros (um inteiro, uma refer�ncia constante para uma string e um booleano) e inicializa os membros da estrutura com esses valores.
//numeroCarteirinha(_numeroCarteirinha): Inicializa o membro numeroCarteirinha com o valor passado como argumento para o construtor.
//nome(_nome): Inicializa o membro nome com o valor passado como argumento para o construtor.
//entrada(_entrada): Inicializa o membro entrada com o valor passado como argumento para o construtor.
//proximo(NULL): Inicializa o ponteiro proximo com o valor NULL, indicando que inicialmente n�o h� uma pr�xima inst�ncia na lista encadeada.
};

struct Socio {
    int numeroTitulo;
    int numeroCarteirinha;
    string nomeTitular;
    string nomeDependente1;
    string nomeDependente2;
    bool pagamentoMensalidadeEmDia;

    Socio()
        : numeroTitulo(0), numeroCarteirinha(0), pagamentoMensalidadeEmDia(false) {} 
//int numeroTitulo: � uma vari�vel inteira que armazena o n�mero do t�tulo do s�cio.
//int numeroCarteirinha: � uma vari�vel inteira que armazena o n�mero da carteirinha do s�cio.
//string nomeTitular: � uma vari�vel do tipo string que armazena o nome do titular associado ao t�tulo.
//string nomeDependente1: � uma vari�vel do tipo string que armazena o nome do primeiro dependente associado ao t�tulo.
//string nomeDependente2: � uma vari�vel do tipo string que armazena o nome do segundo dependente associado ao t�tulo.
//bool pagamentoMensalidadeEmDia: � uma vari�vel booleana que indica se o pagamento da mensalidade est� em dia (true para em dia, false para em atraso).
//Socio() : numeroTitulo(0), numeroCarteirinha(0), pagamentoMensalidadeEmDia(false) {}: � o construtor da estrutura. 
//Ele inicializa os membros da estrutura com valores padr�o.
//numeroTitulo(0): Inicializa o membro numeroTitulo com o valor 0.
//numeroCarteirinha(0): Inicializa o membro numeroCarteirinha com o valor 0.
//pagamentoMensalidadeEmDia(false): Inicializa o membro pagamentoMensalidadeEmDia com o valor false.
//O construtor padr�o � utilizado para inicializar os membros da estrutura com valores padr�o quando um objeto Socio � criado.
};

struct NodoSocio {
    Socio socio;
    NodoSocio* proximo;

    NodoSocio(const Socio& _socio) : socio(_socio), proximo(NULL) {}
    
/*Socio socio: � uma inst�ncia da estrutura Socio. Isso significa que cada NodoSocio cont�m um objeto do tipo Socio, 
armazenando as informa��es associadas a um s�cio.*/

/*NodoSocio* proximo: � um ponteiro para outra inst�ncia da estrutura NodoSocio. 
Esse ponteiro � utilizado para criar uma lista encadeada, conectando inst�ncias consecutivas da estrutura.*/

/*NodoSocio(const Socio& _socio) : socio(_socio), proximo(NULL) {}: � o construtor da estrutura. 
Ele recebe um par�metro que � uma refer�ncia constante para um objeto do tipo Socio, 
inicializa o membro socio com esse objeto e define o ponteiro proximo como NULL.*/

/*Quando um novo n� � criado usando esse construtor, ele � inicializado com um objeto Socio espec�fico e o ponteiro proximo � definido como NULL, 
indicando que inicialmente n�o h� um pr�ximo n� na lista encadeada.*/
};

class Clube {
    NodoSocio* listaSocios = NULL;
    RegistroEntradaPortaria* registrosEntradaPortaria = NULL;
    
/*NodoSocio* listaSocios = NULL;: Declara um ponteiro para NodoSocio chamado listaSocios. Esse ponteiro � inicializado como NULL, indicando que inicialmente n�o h� nenhum s�cio na lista.

RegistroEntradaPortaria* registrosEntradaPortaria = NULL;: Declara um ponteiro para RegistroEntradaPortaria chamado registrosEntradaPortaria. 
Esse ponteiro � inicializado como NULL, indicando que inicialmente n�o h� nenhum registro de entrada na portaria.

listaSocios: Esse ponteiro ser� utilizado para criar uma lista encadeada de s�cios, onde cada n� (ou n�do) cont�m informa��es sobre um 
s�cio e um ponteiro para o pr�ximo n� na lista.

registrosEntradaPortaria: Esse ponteiro ser� utilizado para criar uma lista encadeada de registros de entrada na portaria, onde cada n� 
cont�m informa��es sobre a entrada de um s�cio e um ponteiro para o pr�ximo n� na lista.

Esses ponteiros s�o inicializados como NULL, indicando que inicialmente as listas est�o vazias. � medida que novos s�cios s�o adicionados ou registros de 
entrada s�o registrados, os ponteiros ser�o ajustados para apontar para os novos elementos, construindo assim as listas encadeadas.*/

    void limparLista() {
        NodoSocio* atual = listaSocios;
        while (atual != NULL) {
            NodoSocio* proximo = atual->proximo;
            delete atual;
            atual = proximo;
        }
        listaSocios = NULL;
        
/*void limparLista():Declara��o do in�cio da fun��o limparLista. Esta fun��o n�o retorna nenhum valor (void), o que significa que ela n�o 
possui um valor de retorno. 

NodoSocio* atual = listaSocios;Cria um ponteiro chamado atual do tipo NodoSocio e o inicializa com o ponteiro para o in�cio da lista de s�cios (listaSocios).  

while (atual != NULL): Inicia um loop que continuar� enquanto o ponteiro atual n�o apontar para NULL, o que significa que h� n�s na lista a serem limpos. 

NodoSocio* proximo = atual->proximo: Cria um ponteiro chamado proximo e o inicializa com o ponteiro para o pr�ximo n� na lista 
(contido no membro proximo do n� atual).

 delete atual: Libera a mem�ria alocada para o n� atual, usando o operador delete. Isso efetivamente remove o n� da lista.
 
 listaSocios = NULL: Ap�s o loop, define o ponteiro listaSocios como NULL, indicando que a lista est� vazia.
 
 Em resumo, essa fun��o limparLista percorre a lista encadeada de s�cios e libera a mem�ria alocada para cada n�, garantindo que a lista seja completamente 
 limpa. Ao final do processo, o ponteiro da lista (listaSocios) � definido como NULL para indicar que a lista est� vazia. 
 Isso � �til para evitar refer�ncias inv�lidas ap�s a libera��o de mem�ria.*/
 
    }

    void limparRegistrosEntradaPortaria() {
        RegistroEntradaPortaria* atual = registrosEntradaPortaria;
        while (atual != NULL) {
            RegistroEntradaPortaria* proximo = atual->proximo;
            delete atual;
            atual = proximo;
        }
        registrosEntradaPortaria = NULL;
        
/*void limparRegistrosEntradaPortaria()
Declara��o do in�cio da fun��o limparRegistrosEntradaPortaria. Assim como a fun��o anterior, esta tamb�m n�o possui um valor de retorno (void).

RegistroEntradaPortaria* atual = registrosEntradaPortaria;
Cria um ponteiro chamado atual do tipo RegistroEntradaPortaria e o inicializa com o ponteiro para o in�cio da lista de registros de entrada na portaria 
(registrosEntradaPortaria).

while (atual != NULL)
Inicia um loop que continuar� enquanto o ponteiro atual n�o apontar para NULL, indicando que h� registros na lista a serem limpos.

RegistroEntradaPortaria* proximo = atual->proximo
Cria um ponteiro chamado proximo e o inicializa com o ponteiro para o pr�ximo registro na lista (contido no membro proximo do registro atual).

delete atual
Libera a mem�ria alocada para o registro de entrada atual, usando o operador delete. Isso efetivamente remove o registro da lista.

atual = proximo
Move o ponteiro atual para o pr�ximo registro na lista, preparando-o para a pr�xima itera��o do loop.

registrosEntradaPortaria = NULL;
Ap�s o loop, define o ponteiro registrosEntradaPortaria como NULL, indicando que a lista est� vazia.

Em resumo, essa fun��o limparRegistrosEntradaPortaria percorre a lista encadeada de registros de entrada na portaria e libera a mem�ria alocada para cada n�, 
garantindo que a lista seja completamente limpa. Ao final do processo, o ponteiro da lista (registrosEntradaPortaria) � definido como NULL para indicar que 
a lista est� vazia.*/
        
    }

    void carregarSociosDoArquivo(const string& nomeArquivo) {
        ifstream arquivo("socios.txt");

        if (arquivo.is_open()) {
            Socio socio;
            while (arquivo >> socio.numeroTitulo >> socio.numeroCarteirinha >> socio.nomeTitular
                   >> socio.nomeDependente1 >> socio.nomeDependente2 >> socio.pagamentoMensalidadeEmDia) {
                inserirSocioNaLista(socio);
            }
            arquivo.close();
        } else {
            cout << "Erro ao abrir o arquivo " << nomeArquivo << "\n";
        }
        
/*Essa fun��o, chamada carregarSociosDoArquivo, tem o prop�sito de ler informa��es de s�cios de um arquivo e inseri-las na lista encadeada de s�cios.

ifstream arquivo("socios.txt")
Cria um objeto ifstream chamado arquivo e o associa ao arquivo chamado "socios.txt". Esse arquivo � aberto para leitura.

if (arquivo.is_open())
Verifica se o arquivo foi aberto com sucesso. Se o arquivo estiver aberto, o c�digo dentro deste bloco ser� executado; caso contr�rio, 
o bloco else ser� executado.

Socio socio;
    while (arquivo >> socio.numeroTitulo >> socio.numeroCarteirinha >> socio.nomeTitular
           >> socio.nomeDependente1 >> socio.nomeDependente2 >> socio.pagamentoMensalidadeEmDia) {
        inserirSocioNaLista(socio);
    }
Declara uma inst�ncia da estrutura Socio chamada socio.
Enquanto for poss�vel ler informa��es do arquivo para os membros da estrutura Socio, o loop continua.
Dentro do loop, cada linha do arquivo � lida e os dados s�o armazenados na inst�ncia socio. 
Em seguida, a fun��o inserirSocioNaLista � chamada para adicionar o s�cio � lista encadeada.

arquivo.close();
Fecha o arquivo ap�s a leitura ter sido conclu�da.

} else {
    cout << "Erro ao abrir o arquivo " << nomeArquivo << "\n";
}
Se o arquivo n�o p�de ser aberto, imprime uma mensagem de erro na sa�da de erro padr�o

Em resumo, essa fun��o l� informa��es de um arquivo chamado "socios.txt", cria inst�ncias da estrutura Socio com esses dados e insere cada s�cio na lista 
encadeada utilizando a fun��o inserirSocioNaLista. Se ocorrer um erro ao abrir o arquivo, uma mensagem de erro � exibida.*/
        
    }

    void salvarSociosNoArquivo(const string& nomeArquivo) {
        ofstream arquivo("socios.txt");

        if (arquivo.is_open()) {
            NodoSocio* atual = listaSocios;
            while (atual != NULL) {
                Socio& socio = atual->socio;
                arquivo << socio.numeroTitulo << " "
                        << socio.numeroCarteirinha << " "
                        << socio.nomeTitular << " "
                        << socio.nomeDependente1 << " "
                        << socio.nomeDependente2 << " "
                        << socio.pagamentoMensalidadeEmDia << "\n";
                atual = atual->proximo;
            }
            arquivo.close();
        } else {
            cout << "Erro ao abrir o arquivo " << nomeArquivo << " para escrita.\n";
        }
        
/*Essa fun��o, chamada salvarSociosNoArquivo, tem o prop�sito de salvar as informa��es 
dos s�cios presentes na lista encadeada em um arquivo chamado "socios.txt". 

ofstream arquivo("socios.txt");
Cria um objeto ofstream chamado arquivo e o associa ao arquivo chamado "socios.txt". Esse arquivo � aberto para escrita.

if (arquivo.is_open()) {
Verifica se o arquivo foi aberto com sucesso. Se o arquivo estiver aberto, o c�digo dentro deste bloco ser� executado; 
caso contr�rio, o bloco else ser� executado.

NodoSocio* atual = listaSocios;
    while (atual != NULL) {
        Socio& socio = atual->socio;
        arquivo << socio.numeroTitulo << " "
                << socio.numeroCarteirinha << " "
                << socio.nomeTitular << " "
                << socio.nomeDependente1 << " "
                << socio.nomeDependente2 << " "
                << socio.pagamentoMensalidadeEmDia << "\n";
        atual = atual->proximo;
    }
Inicia um loop que percorre a lista encadeada de s�cios.
Para cada n� na lista, obt�m as informa��es do s�cio armazenadas no membro socio.
Escreve essas informa��es no arquivo, separadas por espa�os, seguidas de uma quebra de linha para indicar o final de uma linha no arquivo.
Move para o pr�ximo n� na lista.

 arquivo.close();
Fecha o arquivo ap�s a escrita ter sido conclu�da.

} else {
    cout << "Erro ao abrir o arquivo " << nomeArquivo << " para escrita.\n";
}
Se o arquivo n�o p�de ser aberto para escrita, imprime uma mensagem de erro na sa�da de erro padr�o (cout).

Em resumo, essa fun��o percorre a lista encadeada de s�cios, l� as informa��es de cada s�cio e as escreve no arquivo "socios.txt". 
Se ocorrer um erro ao abrir o arquivo, uma mensagem de erro � exibida.*/
        
    }

    void inserirSocioNaLista(Socio& socio) {
        NodoSocio* novoNodo = new NodoSocio(socio);
        novoNodo->proximo = listaSocios;
        listaSocios = novoNodo;
        
/*Essa fun��o, chamada inserirSocioNaLista, tem o prop�sito de adicionar um novo s�cio � lista encadeada de s�cios.

NodoSocio* novoNodo = new NodoSocio(socio);
Cria dinamicamente um novo objeto do tipo NodoSocio usando o operador new. Esse novo n� � inicializado com o s�cio passado como par�metro para a fun��o. 
O operador new aloca mem�ria para esse novo n� no heap.

novoNodo->proximo = listaSocios;
Define o ponteiro proximo do novo n� como o ponteiro para o in�cio da lista de s�cios (listaSocios). 
Isso significa que o novo n� agora aponta para o que antes era o primeiro n� na lista.

listaSocios = novoNodo;
Atualiza o ponteiro listaSocios para apontar para o novo n�. Agora, o novo n� se torna o primeiro n� na lista, e o restante da lista continua a partir dele.

Em resumo, essa fun��o adiciona um novo s�cio � lista encadeada de s�cios. 
Ela cria um novo n� para armazenar as informa��es do s�cio, ajusta o ponteiro proximo desse novo n� para apontar para o que era o primeiro n� na lista e, 
em seguida, atualiza o ponteiro listaSocios para apontar para o novo n�, tornando-o o novo primeiro n� na lista. 
Essa abordagem � conhecida como inser��o no in�cio da lista.

A fun��o inserirSocioNaLista n�o cont�m uma instru��o delete porque ela n�o � respons�vel por liberar a mem�ria associada aos n�s da lista encadeada. 
A fun��o � projetada para inserir um novo s�cio no in�cio da lista e, assim, apenas manipula a atualiza��o de ponteiros.*/
        
    }

    void mostrarInfoSocio(Socio& socio) const {
        cout << "Numero do Titulo: " << socio.numeroTitulo << "\n";
        cout << "Numero da Carteirinha: " << socio.numeroCarteirinha << "\n";
        cout << "Nome do Titular: " << socio.nomeTitular << "\n";
        cout << "Nome do Dependente 1: " << socio.nomeDependente1 << "\n";
        cout << "Nome do Dependente 2: " << socio.nomeDependente2 << "\n";
        cout << "Pagamento em Dia: " << (socio.pagamentoMensalidadeEmDia ? "Sim" : "Nao.") << "\n";
        
/*cout << "Numero do Titulo: " << socio.numeroTitulo << "\n";
Exibe a mensagem "Numero do Titulo: " seguida pelo valor do atributo numeroTitulo do objeto socio.

cout << "Numero da Carteirinha: " << socio.numeroCarteirinha << "\n";
Exibe a mensagem "Numero da Carteirinha: " seguida pelo valor do atributo numeroCarteirinha do objeto socio.

cout << "Nome do Titular: " << socio.nomeTitular << "\n";
Exibe a mensagem "Nome do Titular: " seguida pelo valor do atributo nomeTitular do objeto socio.

cout << "Nome do Dependente 1: " << socio.nomeDependente1 << "\n";
Exibe a mensagem "Nome do Dependente 1: " seguida pelo valor do atributo nomeDependente1 do objeto socio.

cout << "Nome do Dependente 2: " << socio.nomeDependente2 << "\n";
Exibe a mensagem "Nome do Dependente 2: " seguida pelo valor do atributo nomeDependente2 do objeto socio.

cout << "Pagamento em Dia: " << (socio.pagamentoMensalidadeEmDia ? "Sim" : "N�o. Recomenda-se atualizar pagamento.") << "\n";
Se for verdadeiro, exibe "Sim"; caso contr�rio, exibe "N�o. Recomenda-se atualizar pagamento."*/

       cout <<"-------------------------------- \n";
    }

    Socio* encontrarSocioPorCarteirinha(int numeroCarteirinha) const {
        NodoSocio* atual = listaSocios;
        while (atual != NULL) {
            if (atual->socio.numeroCarteirinha == numeroCarteirinha) {
                return &atual->socio;
            }
            atual = atual->proximo;
        }
        return NULL;
        
/*Essa fun��o, tem o objetivo de encontrar um s�cio na lista encadeada atrav�s do n�mero da 
carteirinha e retornar um ponteiro para o objeto Socio correspondente. 

NodoSocio* atual = listaSocios;
Declara e inicializa um ponteiro atual do tipo NodoSocio e o inicializa com o ponteiro para o in�cio da lista de s�cios (listaSocios).

while (atual != NULL) {
Inicia um loop que continuar� enquanto o ponteiro atual n�o apontar para NULL, indicando que ainda h� n�s na lista a serem verificados.

if (atual->socio.numeroCarteirinha == numeroCarteirinha) {
        return &atual->socio;
    }
Dentro do loop, verifica se o n�mero da carteirinha do s�cio no n� atual � igual ao n�mero da carteirinha do argumento.
Se for verdadeiro, retorna o endere�o do objeto Socio associado ao n� atual.

atual = atual->proximo;
Move o ponteiro atual para o pr�ximo n� na lista, preparando-o para a pr�xima itera��o do loop.

return NULL;
Se o n�mero da carteirinha n�o foi encontrado em nenhum n� da lista, retorna NULL para indicar que o s�cio n�o foi encontrado.

Em resumo, essa fun��o percorre a lista encadeada de s�cios procurando por um s�cio com o n�mero da carteirinha especificado. 
Se encontrar, retorna um ponteiro para esse objeto Socio; caso contr�rio, retorna NULL. */
        
    }

    void mostrarSociosNaLista() const {
        NodoSocio* atual = listaSocios;
        while (atual != NULL) {
            mostrarInfoSocio(atual->socio);
            atual = atual->proximo;
        }
        
/*A fun��o mostrarSociosNaLista tem o prop�sito de percorrer a lista encadeada de s�cios e 
exibir as informa��es de cada s�cio usando a fun��o mostrarInfoSocio.

NodoSocio* atual = listaSocios;
Declara e inicializa um ponteiro atual do tipo NodoSocio e o inicializa com o ponteiro para o in�cio da lista de s�cios (listaSocios).

while (atual != NULL) {
Inicia um loop que continuar� enquanto o ponteiro atual n�o apontar para NULL, indicando que ainda h� n�s na lista a serem processados.

mostrarInfoSocio(atual->socio);
Chama a fun��o mostrarInfoSocio, passando como argumento o objeto Socio associado ao n� atual da lista (atual->socio). 
Essa fun��o exibir� as informa��es desse s�cio na tela.

atual = atual->proximo;
Move o ponteiro atual para o pr�ximo n� na lista, preparando-o para a pr�xima itera��o do loop.

Em resumo, essa fun��o percorre a lista encadeada de s�cios e, para cada n� na lista, chama a fun��o mostrarInfoSocio para exibir as informa��es 
desse s�cio na tela. Isso � feito at� que todos os n�s na lista tenham sido processados. */
        
    }

    void mostrarInfoRegistroEntrada(const RegistroEntradaPortaria* registro) {
        cout << "Numero da Carteirinha: " << registro->numeroCarteirinha << "\n";
        cout << "Nome: " << registro->nome << "\n";
        cout << (registro->entrada ? "Entrada" : "Sa�da") << "\n";
        cout << "------------------------\n";
        
/*Esta fun��o serve para mostrar registros de entrsda e sa�da.

Mostra o n�mero da carteirinha do s�cio que registrou sua entrada no clube.

numeroCarteirinha � um membro da estrutura RegistroEntradaPortaria.
Portanto, registro->numeroCarteirinha acessa o valor do membro numeroCarteirinha na estrutura associada ao ponteiro registro.

cout << "Nome: " << registro->nome << "\n";
Exibe a mensagem "Nome: " seguida pelo valor do membro nome da estrutura RegistroEntradaPortaria associada ao ponteiro registro.

determina se o membro entrada da estrutura RegistroEntradaPortaria � verdadeiro ou falso.
Ou seja, se registrar entrada (true) isso aparece "Entrada". quando registra saida (false) isso aparece "Saida".

Em resumo, esta fun��o exibe informa��es espec�ficas de um registro de entrada na portaria na sa�da padr�o.*/
        
    }

    void inserirRegistroEntradaNaLista(RegistroEntradaPortaria* novoRegistro) {
        novoRegistro->proximo = registrosEntradaPortaria;
        registrosEntradaPortaria = novoRegistro;
        
/*Essa fun��o, chamada inserirRegistroEntradaNaLista, tem o prop�sito de 
adicionar um novo registro de entrada � lista encadeada de registros de entrada na portaria.

novoRegistro->proximo = registrosEntradaPortaria;
Define o ponteiro proximo do novo registro como o ponteiro para o in�cio da lista de registros de entrada na portaria (registrosEntradaPortaria).
Isso significa que o novo registro agora aponta para o que antes era o primeiro registro na lista.

registrosEntradaPortaria = novoRegistro;
Atualiza o ponteiro registrosEntradaPortaria para apontar para o novo registro.
Agora, o novo registro se torna o primeiro registro na lista, e o restante da lista continua a partir dele.

Em resumo, essa fun��o adiciona um novo registro de entrada � lista encadeada de registros de entrada na portaria. 
Ela faz isso ajustando o ponteiro proximo do novo registro para apontar para o que antes era o primeiro registro na lista e, 
em seguida, atualiza o ponteiro registrosEntradaPortaria para apontar para o novo registro, tornando-o o novo primeiro registro na lista.
De forma simplificada � uma inser��o no in�cio da lista.*/
        
    }

    bool socioEstaDentroDoClube(int numeroCarteirinha) const {
        RegistroEntradaPortaria* atual = registrosEntradaPortaria;
        while (atual != NULL) {
            if (atual->numeroCarteirinha == numeroCarteirinha && atual->entrada) {
                return true; // Se encontrarmos uma entrada para o n�mero da carteirinha, o s�cio est� dentro do clube
            }
            atual = atual->proximo;
        }
        return false; // Se n�o encontrarmos nenhuma entrada, o s�cio est� fora do clube
        
/*A fun��o socioEstaDentroDoClube tem o prop�sito de verificar se um s�cio est� dentro do clube com base no n�mero da carteirinha. 

RegistroEntradaPortaria* atual = registrosEntradaPortaria;
Declara e inicializa um ponteiro atual do tipo RegistroEntradaPortaria e o inicializa com o 
ponteiro para o in�cio da lista de registros de entrada na portaria (registrosEntradaPortaria).

while (atual != NULL) {
Inicia um loop que continuar� enquanto o ponteiro atual n�o apontar para NULL, indicando que ainda h� registros de entrada a serem verificados.

if (atual->numeroCarteirinha == numeroCarteirinha && atual->entrada) {
        return true; // Se encontrarmos uma entrada para o n�mero da carteirinha, o s�cio est� dentro do clube
    }
Dentro do loop, verifica se o n�mero da carteirinha do registro de entrada atual � igual ao n�mero da carteirinha fornecido 
como argumento (atual->numeroCarteirinha).

Tamb�m verifica se o registro de entrada indica uma entrada (atual->entrada). Se ambas as condi��es forem verdadeiras, significa que h� um registro de 
entrada para o n�mero da carteirinha e a entrada foi registrada, indicando que o s�cio est� dentro do clube. Nesse caso, a fun��o retorna true.

atual = atual->proximo;
Move o ponteiro atual para o pr�ximo registro de entrada na lista, preparando-o para a pr�xima itera��o do loop.

return false; // Se n�o encontrarmos nenhuma entrada, o s�cio est� fora do clube
Se o loop percorrer toda a lista de registros de entrada e n�o encontrar uma entrada 
correspondente ao n�mero da carteirinha, a fun��o retorna false. Isso indica que o s�cio est� fora do clube.*/

    }

public:
/*Quando voc� declara algo como public: em uma classe, voc� est� especificando que os membros 
da classe ser�o acess�veis de fora da classe.*/
	

    ~Clube() {
        limparLista();
        limparRegistrosEntradaPortaria();
        
/*A fun��o ~Clube() � um destrutor da classe Clube em C++. Ele � chamado automaticamente quando um objeto da classe 
� destru�do, atrav�s da palavra-chave delete ou quando o objeto sai do escopo.

Chama a fun��o limparLista() para limpar a lista de s�cios do clube. limparLista() 
� uma fun��o que remove todos os n�s da lista encadeada de s�cios e libera a mem�ria associada a esses n�s.

limparRegistrosEntradaPortaria();
Chama a fun��o limparRegistrosEntradaPortaria() para limpar a lista de registros de entrada na portaria.
Remove todos os n�s da lista encadeada de registros de entrada e libera a mem�ria associada a esses n�s.

Essencialmente, o destrutor est� garantindo que, quando um objeto da classe Clube � destru�do, quaisquer recursos alocados dinamicamente, 
como n�s de lista encadeada, sejam liberados adequadamente para evitar vazamento de mem�ria.*/
        
    }

    void carregarSocios() {
        limparLista();
        carregarSociosDoArquivo("socios.txt");
        cout << "Socios carregados com sucesso.\n";
        
/*limparLista();
Chama a fun��o limparLista(). Essa fun��o � respons�vel por limpar a lista de s�cios, removendo todos os n�s da lista encadeada e 
liberando a mem�ria associada a esses n�s. Isso � feito para garantir que a lista esteja vazia antes de carregar novos s�cios.

carregarSociosDoArquivo("socios.txt");
Chama a fun��o carregarSociosDoArquivo("socios.txt"). Essa fun��o � respons�vel por ler informa��es sobre s�cios do arquivo chamado 
"socios.txt" e inserir essas informa��es na lista de s�cios. 
Cada linha do arquivo pode representar as informa��es de um s�cio, e essas informa��es s�o processadas e adicionadas � lista.

cout << "Socios carregados com sucesso.\n";
Exibe uma mensagem indicando que a carga de s�cios foi bem-sucedida.

Em resumo, a fun��o carregarSocios() realiza as seguintes etapas:

Limpa a lista de s�cios para garantir que esteja vazia.
Carrega os s�cios a partir do arquivo "socios.txt", adicionando-os � lista.
Exibe uma mensagem indicando que a carga de s�cios foi conclu�da com sucesso.*/
        
    }

    void listarSocios() const {
        cout << "Lista de Socios:\n";
        mostrarSociosNaLista();
        cout << endl;
        
/*A fun��o listarSocios() tem o prop�sito de exibir uma lista dos s�cios presentes na lista encadeada.

cout << "Lista de Socios:\n";

Utiliza o objeto cout para imprimir na tela.

mostrarSociosNaLista();
Chama a fun��o mostrarSociosNaLista(). Essa fun��o � respons�vel por 
percorrer a lista encadeada de s�cios e exibir as informa��es de cada s�cio na sa�da padr�o.

cout << endl;
Adiciona uma linha em branco � sa�da padr�o ap�s a exibi��o da lista de s�cios. 

Em resumo, a fun��o listarSocios() serve como uma interface para exibir a lista de s�cios na sa�da padr�o de maneira formatada. 
Ela adiciona um cabe�alho, chama a fun��o que efetivamente mostra os s�cios, e acrescenta uma linha em branco no final. */
        
    }

    void inserirSocio(const Socio& novoSocio) {
        NodoSocio* novoNodo = new NodoSocio(novoSocio);
        novoNodo->proximo = listaSocios;
        listaSocios = novoNodo;

        cout << "Socio inserido com sucesso.\n";
        salvarSociosNoArquivo("socios.txt");
        
/*NodoSocio* novoNodo = new NodoSocio(novoSocio);
Cria um novo objeto NodoSocio dinamicamente usando o operador new. Este novo n� � inicializado com o novo s�cio passado como argumento para a fun��o (novoSocio).
O ponteiro novoNodo agora aponta para o novo n� rec�m-criado.

novoNodo->proximo = listaSocios;
Configura o ponteiro proximo do novo n� para apontar para o que antes era o primeiro n� na lista de s�cios (listaSocios).
Isso significa que o novo n� agora est� no in�cio da lista, e o restante da lista continua a partir dele.

listaSocios = novoNodo;
Atualiza o ponteiro listaSocios para apontar para o novo n�. Agora, o novo n� se torna o primeiro n� na lista, e o restante da lista continua a partir dele.

cout << "Socio inserido com sucesso.\n";
Exibe a mensagem "Socio inserido com sucesso." indicando que a opera��o foi bem-sucedida.

salvarSociosNoArquivo("socios.txt");
Chama a fun��o salvarSociosNoArquivo("socios.txt"). Presumivelmente, essa fun��o � respons�vel por salvar a lista atualizada de s�cios no arquivo "socios.txt". 
Cada vez que um novo s�cio � inserido, a lista � atualizada e salva no arquivo para persist�ncia.

Em resumo, a fun��o inserirSocio adiciona um novo s�cio � lista de s�cios, atualiza a lista e exibe uma mensagem indicando que a opera��o foi bem-sucedida. 

O delete est� na fun��o void limparLista()*/
    }

    void removerSocio(int numeroTitulo) {
        NodoSocio* atual = listaSocios;
        NodoSocio* anterior = NULL;
/*NodoSocio* atual = listaSocios;:
atual � um ponteiro para um objeto do tipo NodoSocio. 
Esse ponteiro est� sendo inicializado com o endere�o do primeiro n� na lista encadeada de s�cios (listaSocios).

Come�amos no in�cio da lista e, � medida que avan�amos na lista, atual � atualizado para apontar para o pr�ximo n�.

NodoSocio* anterior = NULL;
anterior � outro ponteiro para um objeto do tipo NodoSocio. Ele � inicializado como NULL.
Este ponteiro ser� usado para manter uma refer�ncia ao n� anterior � medida que percorremos a lista. 
No in�cio, antes de percorrermos qualquer n�, n�o h� n� anterior, ent�o anterior � NULL.

Em resumo, durante o percurso da lista encadeada, o ponteiro atual � usado para apontar para o n� que estamos atualmente considerando, 
e o ponteiro anterior � usado para manter uma refer�ncia ao n� anterior a atual.*/
        while (atual != NULL && atual->socio.numeroTitulo != numeroTitulo) {
            anterior = atual;
            atual = atual->proximo;
/*Inicia um loop que continua enquanto o ponteiro atual n�o aponta para NULL (indicando que ainda h� n�s na lista) e o 
n�mero do t�tulo do s�cio no n� atual n�o corresponde ao n�mero do t�tulo fornecido.
Dentro do loop, anterior � atualizado para apontar para o n� atual, e atual � movido para o pr�ximo n� na lista.*/            
        }

        if (atual != NULL) {
            if (anterior != NULL) {
                anterior->proximo = atual->proximo;
            } else {
                listaSocios = atual->proximo;
            }

            delete atual;

            cout << "Socio removido com sucesso.\n";
            salvarSociosNoArquivo("socios.txt");
        } else {
            cout << "Socio nao encontrado.\n";
        }
        
/*
if (atual != NULL) 
Esta condi��o verifica se o ponteiro atual n�o � NULL. Se atual for NULL, 
significa que o n�mero do t�tulo fornecido n�o foi encontrado na lista, e n�o h� nenhum n� a ser removido.

if (anterior != NULL) {
        anterior->proximo = atual->proximo;
    } else {
        listaSocios = atual->proximo;
    }
Se anterior n�o for NULL, significa que o n� a ser removido n�o � o primeiro n� na lista. 
Nesse caso, ajustamos o ponteiro proximo do n� anterior para apontar para o pr�ximo n� depois de atual. Isso "pula" atual na lista, efetivamente removendo-o.
Se anterior for NULL, significa que o n� a ser removido � o primeiro n� na lista. 
Nesse caso, atualizamos listaSocios para apontar para o pr�ximo n� depois de atual, tornando o pr�ximo n� o novo primeiro n� na lista.

delete atual;
Ap�s ajustar os ponteiros, este comando libera a mem�ria do n� atual que foi removido. Isso � necess�rio para evitar vazamentos de mem�ria.

cout << "Socio removido com sucesso.\n";
salvarSociosNoArquivo("socios.txt");
Uma mensagem � exibida indicando que o s�cio foi removido com sucesso.
Em seguida, chama a fun��o salvarSociosNoArquivo para salvar a lista atualizada de s�cios no arquivo "socios.txt".

else {
    cout << "Socio nao encontrado.\n";
}
Se a condi��o inicial (atual != NULL) n�o for executada, 
significa que o n�mero do t�tulo n�o foi encontrado na lista. Nesse caso, uma mensagem � exibida indicando que o s�cio n�o foi encontrado.

Em resumo, a fun��o removerSocio verifica se o s�cio com o n�mero do t�tulo fornecido est� presente na lista encadeada. Se estiver, o n� 
correspondente � removido, a mem�ria � liberada, uma mensagem de sucesso � exibida e a lista atualizada � salva no arquivo. 
Se o s�cio n�o for encontrado, uma mensagem informando isso � exibida.
*/    
    }

    void checarPortaria() {
        cout << "Socios Inadimplentes:\n";
        NodoSocio* atual = listaSocios;

        while (atual != NULL) {
            if (!atual->socio.pagamentoMensalidadeEmDia) {
                mostrarInfoSocio(atual->socio);
            }
            atual = atual->proximo;
        }
        cout << endl;
        
/*cout << "Socios Inadimplentes:\n";:
Utiliza o objeto cout para imprimir na sa�da padr�o.

NodoSocio* atual = listaSocios;:
Cria um ponteiro atual e o inicializa com o in�cio da lista de s�cios (listaSocios).

while (atual != NULL) {
    if (!atual->socio.pagamentoMensalidadeEmDia) {
        mostrarInfoSocio(atual->socio);
    }
    atual = atual->proximo;
}
Inicia um loop que continua enquanto o ponteiro atual n�o � NULL, ou seja, enquanto ainda h� n�s na lista.
Dentro do loop, verifica se o pagamento da mensalidade do s�cio no n� atual n�o est� em dia (!atual->socio.pagamentoMensalidadeEmDia).
Se o s�cio estiver inadimplente, chama a fun��o mostrarInfoSocio para exibir informa��es sobre esse s�cio.

Em resumo, a fun��o checarPortaria percorre a lista de s�cios, identifica aqueles cujo 
pagamento da mensalidade n�o est� em dia e exibe informa��es sobre esses s�cios na sa�da padr�o.*/
        
    }

    void registrarEntradaSaida() {
        int numeroCarteirinha;
        cout << "Informe o numero da carteirinha: ";
        cin >> numeroCarteirinha;

        Socio* socio = encontrarSocioPorCarteirinha(numeroCarteirinha);

        if (socio != NULL && socio->pagamentoMensalidadeEmDia) {
            RegistroEntradaPortaria* novoRegistro = new RegistroEntradaPortaria(numeroCarteirinha, socio->nomeTitular, true);
            inserirRegistroEntradaNaLista(novoRegistro);

            cout << "Entrada registrada com sucesso.\n";
        } else {
            cout << "Socio nao encontrado ou inadimplente. Nao foi possivel registrar a entrada.\n";
        }
/*       
int numeroCarteirinha;
cout << "Informe o numero da carteirinha: ";
cin >> numeroCarteirinha;
Solicita ao usu�rio que informe o n�mero da carteirinha.
L� o n�mero da carteirinha inserido pelo usu�rio e o armazena na vari�vel numeroCarteirinha.

Socio* socio = encontrarSocioPorCarteirinha(numeroCarteirinha);
Chama a fun��o encontrarSocioPorCarteirinha para buscar na lista de s�cios um s�cio com o n�mero da carteirinha fornecido.
O ponteiro socio agora aponta para o s�cio encontrado ou � NULL se nenhum s�cio for encontrado.

if (socio != NULL && socio->pagamentoMensalidadeEmDia) {
Verifica se socio n�o � NULL (ou seja, se o s�cio foi encontrado) e se o pagamento da mensalidade desse s�cio est� em dia.

RegistroEntradaPortaria* novoRegistro = new RegistroEntradaPortaria(numeroCarteirinha, socio->nomeTitular, true);
Cria dinamicamente um novo objeto RegistroEntradaPortaria representando a entrada do s�cio no clube.
Inicializa o novo registro com o n�mero da carteirinha, o nome do titular do s�cio e define a entrada como true.

inserirRegistroEntradaNaLista(novoRegistro);
Chama a fun��o inserirRegistroEntradaNaLista para adicionar o novo registro � lista de registros de entrada na portaria.

else {
    cout << "Socio nao encontrado ou inadimplente. Nao foi possivel registrar a entrada.\n";
Se o s�cio n�o for encontrado ou estiver inadimplente, exibe uma mensagem informando que n�o foi poss�vel registrar a entrada.

Em resumo, a fun��o solicita e obt�m o n�mero da carteirinha do usu�rio, busca o s�cio correspondente, 
verifica se o s�cio existe e est� adimplente, registra a entrada na portaria se as condi��es forem 
atendidas e exibe mensagens apropriadas com base no resultado.
*/
    }

    void registrarSaida() {
        int numeroCarteirinha;
        cout << "Informe o numero da carteirinha: ";
        cin >> numeroCarteirinha;

        Socio* socio = encontrarSocioPorCarteirinha(numeroCarteirinha);
        
/*int numeroCarteirinha;
cout << "Informe o numero da carteirinha: ";
cin >> numeroCarteirinha;
Solicita ao usu�rio que informe o n�mero da carteirinha.
L� o n�mero da carteirinha inserido pelo usu�rio e o armazena na vari�vel numeroCarteirinha.

Socio* socio = encontrarSocioPorCarteirinha(numeroCarteirinha);
Chama a fun��o encontrarSocioPorCarteirinha para buscar na lista de s�cios um s�cio com o n�mero da carteirinha fornecido.
O ponteiro socio agora aponta para o s�cio encontrado ou � NULL se nenhum s�cio for encontrado.*/

        if (socio != NULL) {
            RegistroEntradaPortaria* novoRegistro = new RegistroEntradaPortaria(numeroCarteirinha, socio->nomeTitular, false);
            inserirRegistroEntradaNaLista(novoRegistro);

            cout << "Saida registrada com sucesso.\n";
        } else {
            cout << "Socio nao encontrado. Nao foi possivel registrar a saida.\n";
        }
/*if (socio != NULL) {
Verifica se o ponteiro socio n�o � NULL, ou seja, se o s�cio foi encontrado na lista com base no n�mero da carteirinha fornecido.

RegistroEntradaPortaria* novoRegistro = new RegistroEntradaPortaria(numeroCarteirinha, socio->nomeTitular, false);
Cria dinamicamente um novo objeto RegistroEntradaPortaria representando a sa�da do s�cio do clube.
Inicializa o novo registro com o n�mero da carteirinha, o nome do titular do s�cio e define a entrada como false, indicando que se trata de uma sa�da.*/
    }

    void atualizarPagamento() {
        int numeroCarteirinha;
        cout << "Informe o numero da carteirinha: ";
        cin >> numeroCarteirinha;

        Socio* socio = encontrarSocioPorCarteirinha(numeroCarteirinha);

/*int numeroCarteirinha;
cout << "Informe o numero da carteirinha: ";
cin >> numeroCarteirinha;
Solicita ao usu�rio que informe o n�mero da carteirinha.
L� o n�mero da carteirinha inserido pelo usu�rio e o armazena na vari�vel numeroCarteirinha.

Socio* socio = encontrarSocioPorCarteirinha(numeroCarteirinha);
Chama a fun��o encontrarSocioPorCarteirinha para buscar na lista de s�cios um s�cio com o n�mero da carteirinha fornecido.
O ponteiro socio agora aponta para o s�cio encontrado ou � NULL se nenhum s�cio for encontrado.*/

        if (socio != NULL) {
            cout << "Pagamento em dia (1 para Sim, 0 para N�o): ";
            cin >> socio->pagamentoMensalidadeEmDia;

            cout << "Pagamento atualizado com sucesso.\n";
            salvarSociosNoArquivo("socios.txt");
        } else {
            cout << "Socio nao encontrado. Nao foi possivel atualizar o pagamento.\n";
        }
/*if (socio != NULL) {
Verifica se o ponteiro socio n�o � NULL, ou seja, se o s�cio foi encontrado na lista com base no n�mero da carteirinha fornecido.

cout << "Pagamento em dia (1 para Sim, 0 para N�o): ";
cin >> socio->pagamentoMensalidadeEmDia;
Exibe uma mensagem solicitando ao usu�rio que informe se o pagamento est� em dia.
L� a resposta do usu�rio (1 para "Sim" ou 0 para "N�o") e atualiza o campo pagamentoMensalidadeEmDia no objeto socio com essa informa��o.

cout << "Pagamento atualizado com sucesso.\n";
salvarSociosNoArquivo("socios.txt");
Se o s�cio foi encontrado e o status de pagamento foi atualizado, exibe uma mensagem indicando que o pagamento foi atualizado com sucesso.
Chama a fun��o salvarSociosNoArquivo para salvar a lista atualizada de s�cios no arquivo "socios.txt".

else {
    cout << "Socio nao encontrado. Nao foi possivel atualizar o pagamento.\n";
}
Se o s�cio n�o foi encontrado (ou seja, o ponteiro socio � NULL), exibe uma mensagem indicando que n�o foi poss�vel atualizar o pagamento.*/
    }

    void gerarRelatorioVisitas(const string& nomeArquivo) {
        ofstream arquivo("relatorio_visitas.txt");
        
/*ofstream arquivo("relatorio_visitas.txt", ios::app);
Cria um objeto ofstream chamado arquivo associado ao arquivo "relatorio_visitas.txt".
O segundo par�metro ios::app indica que o arquivo ser� aberto em modo de acumula��o, ou seja, o conte�do ser� adicionado ao final do arquivo, preservando o conte�do existente.

ofstream (output file stream): Usada para escrita de dados em arquivos.

RegistroEntradaPortaria* atual = registrosEntradaPortaria;
while (atual != NULL) {
Inicia um loop que percorre a lista de registros de entrada/sa�da na portaria.*/

        if (arquivo.is_open()) {
            RegistroEntradaPortaria* atual = registrosEntradaPortaria;
            while (atual != NULL) {
                if (atual->entrada) {
                    arquivo << "Entrada: ";
                } else {
                    arquivo << "Sa�da: ";
                }
                
/*Verifica se o registro � de entrada (atual->entrada � true) ou de sa�da (atual->entrada � false).
Adiciona a informa��o correspondente ("Entrada" ou "Sa�da") ao arquivo.*/

                arquivo << "\n Numero da Carteirinha: " << atual->numeroCarteirinha << "\n";
                arquivo << "Nome: " << atual->nome << "\n";
                arquivo << "------------------------\n";
/*Adiciona ao arquivo o n�mero da carteirinha, nome e uma linha de separa��o para cada registro de entrada/sa�da.*/

                atual = atual->proximo;
/*Move o ponteiro atual para o pr�ximo registro de entrada/sa�da na lista.*/
            }
            arquivo.close();
/*Fecha o arquivo ap�s o t�rmino do loop.*/
            cout << "Relat�rio de visitas gerado com sucesso no arquivo " << nomeArquivo << "\n";
        } else {
            cerr << "Erro ao abrir o arquivo " << nomeArquivo << " para escrita.\n";
        }
    }
};

int main() {
    Clube clube; //Isso declara uma vari�vel  clube da classe Clube e usa o construtor padr�o

    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Carregar s�cios\n";
        cout << "2. Listar s�cios\n";
        cout << "3. Inserir s�cio\n";
        cout << "4. Remover s�cio\n";
        cout << "5. Checar portaria\n";
        cout << "6. Registrar entrada\n";
        cout << "7. Registrar sa�da\n";
        cout << "8. Alterar pagamento\n";
        cout << "9. Gerar relat�rio de visitas no dia\n";
        cout << "10. Sair \n";

        int opcao;
        cout << "Escolha uma op��o: ";
        while (!(cin >> opcao)) {
            cout << "Entrada inv�lida. Digite um n�mero.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Escolha uma op��o: ";
        }
/*Inicia um loop while que continuar� executando enquanto a entrada n�o for v�lida.
A condi��o !(cin >> opcao) verifica se a opera��o de leitura (cin >> opcao) foi bem-sucedida. Se n�o, isso significa que a entrada n�o foi um n�mero inteiro v�lido.

cin.clear() � utilizado para limpar o estado de erro do objeto cin ap�s uma falha de leitura.
cin.ignore(numeric_limits<streamsize>::max(), '\n') descarta qualquer entrada remanescente evitando loops infinitos em caso de entrada inv�lida.*/

        cout << endl;
        switch (opcao) {
            case 1:
                clube.carregarSocios();
                break;
            case 2:
                clube.listarSocios();
                break;
            case 3: {
                Socio novoSocio;
                cout << "Numero do Titulo: ";
                while (!(cin >> novoSocio.numeroTitulo)) {
                    cout << "Entrada inv�lida. Digite um n�mero.\n";
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Numero do Titulo: ";
                } /*n�o permite a entrada de letras somente de n�meros*/

                cout << "Numero da Carteirinha: ";
                while (!(cin >> novoSocio.numeroCarteirinha)) {
                    cout << "Entrada inv�lida. Digite um n�mero.\n";
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Numero da Carteirinha: ";
				}            

                cout << "Nome do Titular: ";
                cin.ignore();
                getline(cin, novoSocio.nomeTitular);

                cout << "Nome do Dependente 1: ";
                getline(cin, novoSocio.nomeDependente1);

                cout << "Nome do Dependente 2: ";
                getline(cin, novoSocio.nomeDependente2);

                cout << "Pagamento em Dia (1 para Sim, 0 para N�o): ";
                while (!(cin >> novoSocio.pagamentoMensalidadeEmDia)) {
                    cout << "Entrada inv�lida. Digite 1 para Sim ou 0 para N�o.\n";
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Pagamento em Dia (1 para Sim, 0 para N�o): ";
                }

                clube.inserirSocio(novoSocio);
                break;
            }
            case 4: {
                int numeroTitulo;
                cout << "Numero do Titulo do S�cio a ser removido: ";
                while (!(cin >> numeroTitulo)) {
                    cout << "Entrada inv�lida. Digite um n�mero.\n";
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << "Numero do Titulo do S�cio a ser removido: ";
                }
                clube.removerSocio(numeroTitulo);
                break;
            }
            case 5:
                clube.checarPortaria();
                break;
            case 6:
                clube.registrarEntradaSaida();
                break;
            case 7:
                clube.registrarSaida();
                break;
            case 8:
                clube.atualizarPagamento();
                break;
            case 9:
                clube.gerarRelatorioVisitas("relatorio_visitas.txt");
                break;
            case 10:
                cout << "Saindo do programa. At� logo\n";
                return 0;
            default:
                cout << "Op��o inv�lida. Tente novamente.\n";
        }
    }

    return 0;
}
